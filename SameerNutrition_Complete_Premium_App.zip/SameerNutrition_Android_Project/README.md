# SAMEER NUTRITION — Complete Android Starter

Premium supplement-store Android app starter with:
- Premium SAMEER NUTRITION branding/logo
- Product catalog and categories
- Search
- Cart and checkout
- Cash on Delivery order flow
- Local customer profile (name/mobile/email)
- Wishlist
- Local last-order history
- Online payment gateway placeholder
- AndroidX + GitHub Actions friendly Gradle project

## Important for production
This starter stores profile/order demo data locally on the device. For a real public store, connect a secure backend/database for accounts, inventory and orders, and use a server-side payment order/signature/webhook verification flow. Never place payment secrets in the APK or GitHub.
