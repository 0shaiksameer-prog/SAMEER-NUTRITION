# SAMEER NUTRITION v1.5

Premium gym-supplement marketplace app. Features include account/login, search, A-Z supplement categories, brands, wishlist, delivery location, stock, product detail, cart, checkout, COD/UPI/card selection, orders, no-return/no-refund policy UI, Paytm Business/UPI payment option placeholder, and customer care.

This is a store-style marketplace UI, not an exact copy of Amazon branding or interface. Product prices/stock are sample data and should be replaced with actual inventory and authorized product listings before public launch.


## Payment setup
The checkout includes a Paytm Business / UPI option. To process real payments, configure your actual merchant UPI ID/QR or Paytm Payment Gateway credentials. Never put private API secrets in the Android app or GitHub. The app currently records the selected payment method locally; it does not perform server-side payment verification.

## Returns policy
The UI states that supplement orders are final with no returns/refunds for change of mind, taste, opened/used packs, or incorrect selection. Any rights or remedies required by applicable consumer law must still be honored.
