package com.sameernutrition.app;

import android.app.*;
import android.os.Bundle;
import android.content.*;
import android.graphics.Color;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.text.InputType;
import android.view.*;
import android.widget.*;
import java.util.*;

public class MainActivity extends Activity {
    static class Product {
        String brand,name,cat,size; int price,stock;
        Product(String b,String n,String c,String s,int p,int st){brand=b;name=n;cat=c;size=s;price=p;stock=st;}
        String title(){return brand+" • "+name;}
    }

    final Product[] products = {
        new Product("MuscleBlaze","Pre Workout 200 Xtreme","PRE-WORKOUT","100 g",799,12),
        new Product("MuscleBlaze","Pre Workout WrathX","PRE-WORKOUT","240 g",1499,8),
        new Product("MuscleBlaze","Creatine Monohydrate","CREATINE","100 g",599,20),
        new Product("MuscleBlaze","Creatine CreAMP","CREATINE","100 g",799,15),
        new Product("MuscleBlaze","Biozyme Performance Whey","WHEY","1 kg",3299,10),
        new Product("MuscleBlaze","Biozyme Whey PR","WHEY","1 kg",2799,14),
        new Product("MuscleBlaze","MB-Vite Daily Multivitamin","MULTIVITAMIN","60 tablets",599,18),
        new Product("MuscleBlaze","Multivitamin for Men","MULTIVITAMIN","60 tablets",699,10),

        new Product("Optimum Nutrition","Gold Standard Pre Workout","PRE-WORKOUT","30 servings",2299,7),
        new Product("Optimum Nutrition","Micronized Creatine Powder","CREATINE","250 g",1799,9),
        new Product("Optimum Nutrition","Gold Standard 100% Whey","WHEY","1 kg",4999,8),
        new Product("Optimum Nutrition","Opti-Men Multivitamin","MULTIVITAMIN","90 tablets",1799,6),

        new Product("GNC","Pre-Workout Amplified","PRE-WORKOUT","30 servings",1999,8),
        new Product("GNC","Creatine Monohydrate","CREATINE","250 g",1899,10),
        new Product("GNC","Pro Performance Whey","WHEY","1 kg",3499,9),
        new Product("GNC","Mega Men Sport","MULTIVITAMIN","90 tablets",1499,7),

        new Product("MyProtein","THE Pre-Workout","PRE-WORKOUT","320 g",2499,6),
        new Product("MyProtein","Creatine Monohydrate","CREATINE","250 g",1599,12),
        new Product("MyProtein","Impact Whey Protein","WHEY","1 kg",2999,11),
        new Product("MyProtein","Alpha Men Multivitamin","MULTIVITAMIN","120 tablets",1399,5),

        new Product("AS-IT-IS Nutrition","PRE WORKOUT","PRE-WORKOUT","100 g",799,15),
        new Product("AS-IT-IS Nutrition","Creatine Monohydrate","CREATINE","250 g",749,22),
        new Product("AS-IT-IS Nutrition","ATOM Whey Protein","WHEY","1 kg",2299,12),
        new Product("AS-IT-IS Nutrition","Multivitamin","MULTIVITAMIN","60 tablets",499,20),

        new Product("Avvatar","Pre Workout","PRE-WORKOUT","30 servings",1299,8),
        new Product("Avvatar","Creatine Monohydrate","CREATINE","100 g",799,12),
        new Product("Avvatar","Whey Protein","WHEY","1 kg",3199,10),
        new Product("Avvatar","Multivitamin","MULTIVITAMIN","60 tablets",699,8),

        new Product("Nakpro","Pre Workout","PRE-WORKOUT","100 g",699,16),
        new Product("Nakpro","Creatine Monohydrate","CREATINE","250 g",699,20),
        new Product("Nakpro","Perform Whey","WHEY","1 kg",1999,14),
        new Product("Nakpro","Multivitamin","MULTIVITAMIN","60 tablets",399,18),

        new Product("MuscleTech","Shatter Elite","PRE-WORKOUT","30 servings",2499,5),
        new Product("MuscleTech","Platinum Creatine","CREATINE","400 g",1999,7),
        new Product("MuscleTech","Nitro-Tech Whey","WHEY","1 kg",4299,6),
        new Product("MuscleTech","Platinum Multivitamin","MULTIVITAMIN","90 tablets",1299,5),

        new Product("Cellucor","C4 Original","PRE-WORKOUT","30 servings",1999,7),
        new Product("Cellucor","Creatine","CREATINE","72 servings",1799,8),
        new Product("Cellucor","COR Performance Whey","WHEY","1 kg",2999,8),
        new Product("Cellucor","Alpha Amino Multi","MULTIVITAMIN","60 tablets",999,6),

        new Product("Universal Nutrition","Animal Fury","PRE-WORKOUT","30 servings",2299,5),
        new Product("Universal Nutrition","Creatine","CREATINE","200 g",1399,6),
        new Product("Universal Nutrition","Ultra Whey Pro","WHEY","1 kg",2799,7),
        new Product("Universal Nutrition","Daily Formula","MULTIVITAMIN","100 tablets",1199,5),

        new Product("MusclePharm","Assault Sport","PRE-WORKOUT","30 servings",1999,6),
        new Product("MusclePharm","Creatine","CREATINE","300 g",1499,8),
        new Product("MusclePharm","Combat 100% Whey","WHEY","1 kg",2999,8),
        new Product("MusclePharm","Core Series Multi","MULTIVITAMIN","90 tablets",1099,6),

        new Product("HealthKart","HK Vitals Pre Workout","PRE-WORKOUT","30 servings",899,15),
        new Product("HealthKart","HK Vitals Creatine","CREATINE","100 g",649,18),
        new Product("HealthKart","HK Vitals Whey Protein","WHEY","1 kg",2299,15),
        new Product("HealthKart","HK Vitals Multivitamin","MULTIVITAMIN","60 tablets",499,20),

        new Product("The Whole Truth","Protein Bar","SNACKS","6 bars",699,10),
        new Product("Wellbeing Nutrition","Melts Multivitamin","MULTIVITAMIN","30 strips",799,8),
        new Product("HealthKart","Fish Oil Omega 3","OMEGA-3","60 softgels",499,12),
        new Product("MuscleBlaze","Mass Gainer XXL","GAINER","3 kg",2499,8),
        new Product("Optimum Nutrition","Serious Mass","GAINER","2.7 kg",4299,5),
        new Product("MyProtein","Essential BCAA","AMINO","250 g",1299,9),
        new Product("MuscleBlaze","BCAA Pro","AMINO","250 g",999,12),
        new Product("AS-IT-IS Nutrition","L-Glutamine","AMINO","250 g",899,10),
        new Product("GNC","L-Carnitine","FAT BURNER","60 capsules",1299,7),
        new Product("MuscleBlaze","Fish Oil Gold","OMEGA-3","60 capsules",699,15),
        new Product("GNC","Fish Oil","OMEGA-3","100 softgels",999,8),
        new Product("MyProtein","Electrolyte Plus","HYDRATION","20 servings",899,10),
        new Product("MuscleBlaze","Shaker Pro","ACCESSORIES","700 ml",349,30),
        new Product("SAMEER NUTRITION","Premium Shaker","ACCESSORIES","750 ml",399,30),
        new Product("MuscleBlaze","Super Gainer XXL","GAINER","3 kg",2599,7),
        new Product("MuscleBlaze","L-Carnitine 3000","FAT BURNER","60 capsules",899,10),
        new Product("MuscleBlaze","Fish Oil 1000","OMEGA-3","60 softgels",699,14),
        new Product("MuscleBlaze","Electrolyte Powder","HYDRATION","200 g",499,16),
        new Product("Optimum Nutrition","Amino Energy","AMINO","270 g",2199,7),
        new Product("Optimum Nutrition","Opti-Women","MULTIVITAMIN","60 capsules",1599,6),
        new Product("Optimum Nutrition","Fish Oil Softgels","OMEGA-3","100 softgels",1499,5),
        new Product("GNC","L-Glutamine","AMINO","180 g",1399,7),
        new Product("GNC","Mega Men One Daily","MULTIVITAMIN","60 tablets",1299,8),
        new Product("GNC","Triple Strength Fish Oil","OMEGA-3","60 softgels",1799,5),
        new Product("MyProtein","Pre-Workout Blend","PRE-WORKOUT","250 g",1799,8),
        new Product("MyProtein","Weight Gainer Blend","GAINER","2.5 kg",2999,7),
        new Product("MyProtein","BCAA 2:1:1","AMINO","250 g",1199,10),
        new Product("MyProtein","Omega 3 Softgels","OMEGA-3","100 softgels",999,8),
        new Product("AS-IT-IS Nutrition","Whey Protein Concentrate","WHEY","1 kg",2199,13),
        new Product("AS-IT-IS Nutrition","Mass Gainer","GAINER","3 kg",2299,9),
        new Product("AS-IT-IS Nutrition","Electrolytes","HYDRATION","250 g",599,14),
        new Product("Avvatar","Mass Gainer","GAINER","3 kg",2699,7),
        new Product("Avvatar","L-Carnitine","FAT BURNER","60 capsules",999,8),
        new Product("Avvatar","Omega 3","OMEGA-3","60 softgels",699,10),
        new Product("Nakpro","Impact Whey","WHEY","1 kg",1899,12),
        new Product("Nakpro","Mass Gainer","GAINER","3 kg",1999,11),
        new Product("Nakpro","Electrolyte","HYDRATION","200 g",499,15),
        new Product("MuscleTech","Mass-Tech Elite","GAINER","2.7 kg",4499,5),
        new Product("MuscleTech","Platinum Multivitamin","MULTIVITAMIN","90 tablets",1399,6),
        new Product("Cellucor","Alpha Amino","AMINO","30 servings",1899,6),
        new Product("Cellucor","C4 Sport","PRE-WORKOUT","30 servings",1699,8),
        new Product("Universal Nutrition","Animal Pak","MULTIVITAMIN","30 packs",1999,5),
        new Product("Universal Nutrition","Animal Whey","WHEY","2 kg",4299,5),
        new Product("MusclePharm","BCAA 3:1:2","AMINO","200 g",1199,7),
        new Product("MusclePharm","Glutamine","AMINO","300 g",1399,6),
        new Product("HealthKart","HK Vitals Fish Oil","OMEGA-3","60 softgels",549,15),
        new Product("HealthKart","HK Vitals Electrolytes","HYDRATION","20 servings",399,18),
        new Product("HealthKart","HK Vitals BCAA","AMINO","200 g",699,14),
        new Product("Wellbeing Nutrition","Melts Multivitamin Women","MULTIVITAMIN","30 strips",799,8),
        new Product("Wellbeing Nutrition","Melts Vitamin D3","VITAMIN-D","30 strips",699,10),
        new Product("The Whole Truth","Protein Bar Peanut","SNACKS","6 bars",699,10),
        new Product("The Whole Truth","Protein Bar Dark Chocolate","SNACKS","6 bars",749,9),
        new Product("SAMEER NUTRITION","Creatine Monohydrate","CREATINE","250 g",699,25),
        new Product("SAMEER NUTRITION","Whey Protein Blend","WHEY","1 kg",2199,20),
        new Product("SAMEER NUTRITION","Pre Workout Pro","PRE-WORKOUT","30 servings",999,20),
        new Product("SAMEER NUTRITION","Daily Multivitamin","MULTIVITAMIN","60 tablets",499,25),
        new Product("SAMEER NUTRITION","Mass Gainer Pro","GAINER","3 kg",2399,15),
        new Product("SAMEER NUTRITION","BCAA Recovery","AMINO","250 g",799,18),
        new Product("SAMEER NUTRITION","Omega 3","OMEGA-3","60 softgels",599,20),
        new Product("SAMEER NUTRITION","Electrolyte Hydration","HYDRATION","20 servings",399,20),
        new Product("SAMEER NUTRITION","L-Carnitine","FAT BURNER","60 capsules",799,15),
        new Product("SAMEER NUTRITION","Vitamin D3","VITAMIN-D","60 tablets",299,25),
        new Product("SAMEER NUTRITION","Protein Bars","SNACKS","6 bars",499,20)
    };

    SharedPreferences sp; ArrayList<Product> cart=new ArrayList<>(); HashSet<String> wish=new HashSet<>();
    LinearLayout root,content;
    final int dark=Color.rgb(17,19,24), orange=Color.rgb(255,122,24), green=Color.rgb(25,179,107), purple=Color.rgb(110,74,232), blue=Color.rgb(31,155,209), bg=Color.rgb(246,247,250);

    @Override public void onCreate(Bundle b){super.onCreate(b);sp=getSharedPreferences("sameer_nutrition",0); if(sp.getBoolean("logged",false))showHome();else showWelcome();}
    GradientDrawable bg(int c,float r){GradientDrawable g=new GradientDrawable();g.setColor(c);g.setCornerRadius(r);return g;}
    GradientDrawable outline(int c,int line,float r){GradientDrawable g=bg(c,r);g.setStroke(2,line);return g;}
    TextView tv(String s,float z,int c,boolean bold){TextView t=new TextView(this);t.setText(s);t.setTextSize(z);t.setTextColor(c);if(bold)t.setTypeface(Typeface.DEFAULT,Typeface.BOLD);return t;}
    Button btn(String s,int c){Button b=new Button(this);b.setText(s);b.setTextColor(Color.WHITE);b.setTextSize(12);b.setAllCaps(false);b.setTypeface(Typeface.DEFAULT,Typeface.BOLD);b.setBackground(bg(c,22));return b;}
    EditText input(String h,int type){EditText e=new EditText(this);e.setHint(h);e.setTextSize(15);e.setInputType(type);e.setSingleLine(true);e.setPadding(16,0,16,0);e.setBackground(outline(Color.WHITE,Color.rgb(218,220,225),18));return e;}
    LinearLayout col(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.VERTICAL);return l;}
    LinearLayout row(){LinearLayout l=new LinearLayout(this);l.setOrientation(LinearLayout.HORIZONTAL);l.setGravity(Gravity.CENTER_VERTICAL);return l;}
    void add(LinearLayout p,View v,int w,int h,int l,int t,int r,int b){LinearLayout.LayoutParams q=new LinearLayout.LayoutParams(w,h);q.setMargins(l,t,r,b);p.addView(v,q);}
    void weight(LinearLayout p,View v){p.addView(v,new LinearLayout.LayoutParams(0,-1,1));}
    void base(){root=col();root.setBackgroundColor(bg);setContentView(root);content=col();ScrollView s=new ScrollView(this);s.setFillViewport(true);s.addView(content);root.addView(s,new LinearLayout.LayoutParams(-1,0,1));}
    void logo(LinearLayout p,int sz){
        LinearLayout card=col(); card.setGravity(Gravity.CENTER);
        GradientDrawable gd=new GradientDrawable(GradientDrawable.Orientation.TL_BR,new int[]{Color.rgb(255,91,46),Color.rgb(110,74,232),Color.rgb(25,179,107),Color.rgb(31,155,209)}); gd.setCornerRadius(28);
        TextView mark=tv("SN",34,Color.WHITE,true); mark.setGravity(Gravity.CENTER); mark.setBackground(gd);
        add(card,mark,Math.min(sz,104),Math.min(sz,104),0,0,0,4);
        TextView sub=tv("SAMEER NUTRITION",8,Color.DKGRAY,true); sub.setGravity(Gravity.CENTER); card.addView(sub);
        add(p,card,sz,sz+20,0,8,0,4);
    }

    void showWelcome(){base();LinearLayout p=col();p.setPadding(28,30,28,30);p.setGravity(Gravity.CENTER_HORIZONTAL);logo(p,120);TextView a=tv("SAMEER NUTRITION",28,dark,true);a.setGravity(17);add(p,a,-1,44,0,5,0,2);TextView s=tv("OFFICIAL SUPPLEMENT STORE",12,orange,true);s.setGravity(17);add(p,s,-1,28,0,0,0,22);LinearLayout hero=row();hero.setPadding(18,12,18,12);hero.setBackground(bg(dark,24));TextView h=tv("REAL BRANDS\nFITNESS • NUTRITION\nFAST DELIVERY",17,Color.WHITE,true);weight(hero,h);TextView badge=tv("SN\nSHOP",13,Color.WHITE,true);badge.setGravity(17);badge.setBackground(bg(orange,22));add(hero,badge,78,78,8,0,0,0);add(p,hero,-1,100,0,0,0,22);Button c=btn("CREATE ACCOUNT",green),l=btn("LOGIN",dark);add(p,c,-1,56,0,5,0,10);add(p,l,-1,56,0,0,0,18);TextView f=tv("✓ Brand-wise catalogue   ✓ Stock shown   ✓ Delivery & order support",12,Color.GRAY,false);f.setGravity(17);add(p,f,-1,40,0,5,0,0);root.addView(p,new LinearLayout.LayoutParams(-1,-1));c.setOnClickListener(v->createAccount());l.setOnClickListener(v->login());}

    void createAccount(){base();top("Create Account",false);add(content,tv("Join SAMEER NUTRITION",24,dark,true),-1,40,22,26,22,4);add(content,tv("Create your account to shop and track orders.",14,Color.GRAY,false),-1,28,22,0,22,18);EditText n=input("Full name",1),m=input("Mobile number",2),e=input("Email address",33),p=input("Password (6+ characters)",129);add(content,n,-1,54,22,5,22,10);add(content,m,-1,54,22,0,22,10);add(content,e,-1,54,22,0,22,10);add(content,p,-1,54,22,0,22,18);Button b=btn("CREATE ACCOUNT",green);add(content,b,-1,56,22,0,22,12);b.setOnClickListener(v->{if(n.getText().toString().trim().isEmpty()||m.getText().toString().trim().length()<10||p.getText().toString().length()<6){toast("Enter valid name, mobile and 6+ character password");return;}sp.edit().putString("name",n.getText().toString().trim()).putString("mobile",m.getText().toString().trim()).putString("email",e.getText().toString().trim()).putString("pass",p.getText().toString()).putBoolean("logged",true).apply();showHome();});}
    void login(){base();top("Login",false);add(content,tv("Welcome back",25,dark,true),-1,40,22,30,22,4);EditText m=input("Mobile or email",33),p=input("Password",129);add(content,m,-1,54,22,8,22,10);add(content,p,-1,54,22,0,22,18);Button b=btn("LOGIN",dark);add(content,b,-1,56,22,0,22,12);b.setOnClickListener(v->{String x=m.getText().toString().trim(),y=p.getText().toString();if((x.equals(sp.getString("mobile",""))||x.equals(sp.getString("email","")))&&y.equals(sp.getString("pass",""))){sp.edit().putBoolean("logged",true).apply();showHome();}else toast("Account details not found. Create account first.");});}

    void top(String title,boolean back){LinearLayout bar=row();bar.setPadding(8,5,8,5);bar.setBackgroundColor(Color.WHITE);if(back){Button b=btn("‹",dark);add(bar,b,50,48,0,0,5,0);b.setOnClickListener(v->showHome());}else{Space spc=new Space(this);add(bar,spc,50,48,0,0,5,0);}TextView t=tv(title,19,dark,true);weight(bar,t);Button help=btn("HELP",orange);add(bar,help,70,46,5,0,0,0);help.setOnClickListener(v->help());root.addView(bar,new LinearLayout.LayoutParams(-1,58));}
    void homeHeader(){LinearLayout h=col();h.setPadding(16,12,16,8);TextView hi=tv("Hi, "+sp.getString("name","Customer")+" 👋",14,Color.GRAY,false);h.addView(hi);LinearLayout sr=row();EditText q=input("Search products, brands & categories",33);weight(sr,q);Button go=btn("SEARCH",dark);add(sr,go,82,50,7,0,0,0);h.addView(sr);go.setOnClickListener(v->search(q.getText().toString()));content.addView(h);}
    void showHome(){base();homeHeader();LinearLayout hero=row();hero.setPadding(18,14,18,14);hero.setBackground(bg(dark,22));TextView t=tv("AUTHENTIC BRANDS\nGenuine-looking store catalogue\nFast delivery options",16,Color.WHITE,true);weight(hero,t);TextView x=tv("SN\nSTORE",12,Color.WHITE,true);x.setGravity(17);x.setBackground(bg(orange,20));add(hero,x,76,76,5,0,0,0);add(content,hero,-1,100,16,4,16,12);TextView cat=tv("Shop by category",20,dark,true);add(content,cat,-1,34,16,4,16,5);
        LinearLayout quick=row(); Button deal=btn("🔥 DEALS",orange), recent=btn("NEW",purple), wishb=btn("♡ WISHLIST",dark), brandsb=btn("BRANDS",green); weight(quick,deal);weight(quick,recent);weight(quick,wishb);weight(quick,brandsb); add(content,quick,-1,50,10,0,10,8);
        deal.setOnClickListener(v->products("ALL")); recent.setOnClickListener(v->products("ALL")); wishb.setOnClickListener(v->wishlist()); brandsb.setOnClickListener(v->brandList());String[] cs={"ALL","WHEY","ISOLATE","VEGAN PROTEIN","CASEIN","GAINER","CREATINE","PRE-WORKOUT","INTRA-WORKOUT","BCAA","EAA","GLUTAMINE","AMINO","CITRULLINE","BETA-ALANINE","L-CARNITINE","OMEGA-3","MULTIVITAMIN","VITAMIN-D","ELECTROLYTES","FAT BURNER","SNACKS","ACCESSORIES"};LinearLayout chips=row();HorizontalScrollView hs=new HorizontalScrollView(this);hs.addView(chips);for(String c:cs){Button b=btn(c.equals("ALL")?"ALL":c, c.equals("ALL")?green:dark);add(chips,b,WRAP,46,4,2,4,2);b.setOnClickListener(v->products(c));}add(content,hs,-1,55,12,0,12,10);LinearLayout loc=row(); loc.setPadding(12,8,12,8); loc.setBackground(bg(Color.WHITE,18)); TextView lt=tv("📍 Deliver to: "+sp.getString("address","Select delivery location"),13,dark,true); weight(loc,lt); Button change=btn("CHANGE",dark); add(loc,change,82,42,6,0,0,0); add(content,loc,-1,58,16,6,16,10); change.setOnClickListener(v->setLocation());
        TextView br=tv("Popular brands",20,dark,true);add(content,br,-1,34,16,5,16,3);String[] brands={"MuscleBlaze","Optimum Nutrition","GNC","MyProtein","AS-IT-IS Nutrition","Avvatar","Nakpro","MuscleTech","Cellucor","Universal Nutrition","MusclePharm","HealthKart"};LinearLayout grid=col();for(String b:brands){Button x=btn("▣  "+b,dark);add(grid,x,-1,48,16,3,16,3);x.setOnClickListener(v->brand(b));}content.addView(grid);TextView deals=tv("All stocked products",20,dark,true);add(content,deals,-1,34,16,12,16,2);LinearLayout list=col();content.addView(list);for(int i=0;i<products.length;i++)if(i<16)addCard(list,products[i]);bottom();}
    static final int WRAP=-2;
    void setLocation(){ EditText a=input("Delivery address / area",1); a.setText(sp.getString("address","")); new AlertDialog.Builder(this).setTitle("Delivery location").setView(a).setNegativeButton("CANCEL",null).setPositiveButton("SAVE",(d,w)->{sp.edit().putString("address",a.getText().toString().trim()).apply();showHome();}).show(); }
    void brandList(){ base(); top("All Brands",true); LinearLayout l=col(); l.setPadding(10,10,10,18); content.addView(l); String[] bs={"MuscleBlaze","Optimum Nutrition","GNC","MyProtein","AS-IT-IS Nutrition","Avvatar","Nakpro","MuscleTech","Cellucor","Universal Nutrition","MusclePharm","HealthKart","Wellbeing Nutrition","The Whole Truth","SAMEER NUTRITION"}; for(String b:bs){Button x=btn("🏷  "+b,dark); add(l,x,-1,52,8,5,8,5); x.setOnClickListener(v->brand(b));} bottom(); }
    void wishlist(){ base(); top("Wishlist",true); LinearLayout l=col(); l.setPadding(10,10,10,18); content.addView(l); boolean any=false; for(Product p:products) if(wish.contains(p.brand+"|"+p.name)){addCard(l,p);any=true;} if(!any) add(content,tv("Your wishlist is empty. Tap ♡ on products to save them.",16,Color.GRAY,false),-1,180,20,50,20,20); bottom(); }

    void products(String c){base();top(c.equals("ALL")?"All Supplements":c,true);LinearLayout l=col();l.setPadding(10,10,10,18);content.addView(l);for(Product p:products){ boolean ok=c.equals("ALL")||p.cat.equals(c); String n=p.name.toLowerCase(); if(c.equals("ISOLATE")||c.equals("VEGAN PROTEIN")||c.equals("CASEIN")) ok=ok||n.contains(c.toLowerCase())||n.contains("protein"); if(c.equals("INTRA-WORKOUT")||c.equals("EAA")||c.equals("GLUTAMINE")||c.equals("CITRULLINE")||c.equals("BETA-ALANINE")) ok=ok||p.cat.equals("AMINO")||n.contains(c.toLowerCase()); if(c.equals("L-CARNITINE")) ok=ok||p.cat.equals("FAT BURNER")||n.contains("carnitine"); if(c.equals("ELECTROLYTES")) ok=ok||p.cat.equals("HYDRATION"); if(ok)addCard(l,p);}bottom();}
    void brand(String b){base();top(b,true);LinearLayout l=col();l.setPadding(10,10,10,18);content.addView(l);for(Product p:products)if(p.brand.equals(b))addCard(l,p);bottom();}
    void search(String q){base();top("Search",true);LinearLayout l=col();l.setPadding(10,10,10,18);content.addView(l);q=q.toLowerCase();for(Product p:products)if((p.brand+" "+p.name+" "+p.cat).toLowerCase().contains(q))addCard(l,p);}
    void addCard(LinearLayout p,Product x){LinearLayout c=row();c.setPadding(10,9,10,9);c.setBackground(bg(Color.WHITE,18));TextView icon=tv(x.cat.substring(0,1),20,Color.WHITE,true);icon.setGravity(17);icon.setBackground(bg(color(x.cat),18));add(c,icon,60,68,0,0,10,0);LinearLayout info=col();TextView n=tv(x.brand+"\n"+x.name,14,dark,true);TextView z=tv(x.size+" • Stock: "+x.stock,10,Color.GRAY,false);TextView pr=tv("₹"+x.price,17,green,true);info.addView(n);info.addView(z);info.addView(pr);weight(c,info);Button heart=btn(wish.contains(x.brand+"|"+x.name)?"♥":"♡",purple); add(c,heart,48,46,4,0,0,0); heart.setOnClickListener(q->{String k=x.brand+"|"+x.name;if(wish.contains(k))wish.remove(k);else wish.add(k);heart.setText(wish.contains(k)?"♥":"♡");toast(wish.contains(k)?"Added to wishlist":"Removed from wishlist");}); Button v=btn("VIEW",dark);add(c,v,62,46,5,0,0,0);v.setOnClickListener(q->detail(x));Button a=btn("ADD",orange);add(c,a,62,46,4,0,0,0);a.setOnClickListener(q->{if(x.stock<=0){toast("Out of stock");return;}cart.add(x);toast(x.name+" added • "+cart.size()+" item(s)");});LinearLayout.LayoutParams lp=new LinearLayout.LayoutParams(-1,92);lp.setMargins(6,5,6,5);p.addView(c,lp);}
    void detail(Product x){
        base(); top("Product Details",true);
        LinearLayout box=col(); box.setPadding(18,18,18,18);
        TextView badge=tv(x.cat,12,Color.WHITE,true); badge.setGravity(17); badge.setBackground(bg(color(x.cat),18)); add(box,badge,-1,42,0,0,0,12);
        TextView brand=tv(x.brand,15,orange,true); add(box,brand,-1,28,0,0,0,2);
        TextView name=tv(x.name,26,dark,true); add(box,name,-1,70,0,0,0,2);
        TextView size=tv(x.size+"  •  Stock available: "+x.stock,13,Color.GRAY,false); add(box,size,-1,30,0,0,0,8);
        TextView price=tv("₹"+x.price,28,green,true); add(box,price,-1,45,0,0,0,8);
        TextView desc=tv("Authentic supplement-store catalogue item. Check pack size, ingredients, expiry and seller details before purchase. Stock shown is store stock.",14,Color.DKGRAY,false); add(box,desc,-1,90,0,0,0,16);
        Button addb=btn("ADD TO CART",orange); add(box,addb,-1,56,0,0,0,10);
        Button buy=btn("BUY NOW",green); add(box,buy,-1,56,0,0,0,10);
        Button call=btn("CUSTOMER CARE • 6303836274",dark); add(box,call,-1,52,0,0,0,8);
        content.addView(box);
        addb.setOnClickListener(v->{if(x.stock>0){cart.add(x);toast("Added to cart");}else toast("Out of stock");});
        buy.setOnClickListener(v->{if(x.stock>0){cart.add(x);checkout();}else toast("Out of stock");});
        call.setOnClickListener(v->help());
        bottom();
    }

    int color(String c){if(c.equals("PRE-WORKOUT"))return orange;if(c.equals("CREATINE"))return green;if(c.equals("WHEY"))return purple;if(c.equals("MULTIVITAMIN"))return blue;return dark;}
    void bottom(){LinearLayout n=row();n.setPadding(5,4,5,4);n.setBackgroundColor(Color.WHITE);Button h=btn("HOME",green),o=btn("ORDERS",dark),a=btn("ACCOUNT",purple),c=btn("CART ("+cart.size()+")",orange);weight(n,h);weight(n,o);weight(n,a);weight(n,c);root.addView(n,new LinearLayout.LayoutParams(-1,64));h.setOnClickListener(v->showHome());o.setOnClickListener(v->orders());a.setOnClickListener(v->account());c.setOnClickListener(v->cart());}

    void cart(){base();top("Cart",true);if(cart.isEmpty()){add(content,tv("Your cart is empty.",20,Color.GRAY,false),-1,180,20,60,20,20);return;}LinearLayout l=col();l.setPadding(16,12,16,10);content.addView(l);for(Product p:cart)add(l,tv("• "+p.brand+" — "+p.name+"   ₹"+p.price,14,dark,false),-1,52,0,2,0,2);int total=0;for(Product p:cart)total+=p.price;add(content,tv("Total: ₹"+total,22,dark,true),-1,50,20,8,20,12);Button b=btn("CHECKOUT",green);add(content,b,-1,56,20,0,20,15);b.setOnClickListener(v->checkout());}
    void checkout(){LinearLayout f=col();f.setPadding(12,4,12,0);EditText n=input("Full name",1),m=input("Mobile number",2),a=input("Delivery address",1);a.setSingleLine(false);a.setMinLines(3);f.addView(n);f.addView(m);f.addView(a);RadioGroup r=new RadioGroup(this);RadioButton s=new RadioButton(this),d=new RadioButton(this),p=new RadioButton(this);s.setText("SAMEER delivery");d.setText("My delivery app / partner");p.setText("Self pickup");s.setChecked(true);r.addView(s);r.addView(d);r.addView(p);f.addView(r); RadioGroup pay=new RadioGroup(this); RadioButton cod=new RadioButton(this),upi=new RadioButton(this),paytm=new RadioButton(this); cod.setText("Cash on Delivery"); upi.setText("UPI / Online payment"); paytm.setText("Paytm Business / UPI"); cod.setChecked(true); pay.addView(cod); pay.addView(upi); pay.addView(paytm); f.addView(pay); TextView policy=tv("NON-RETURNABLE / NO REFUND POLICY\nSupplement orders are final. No return or refund for change of mind, taste, opened/used packs or incorrect selection. If an item arrives wrong, damaged, defective, or applicable law requires a remedy, contact customer care with your order details.",12,Color.DKGRAY,false); policy.setPadding(12,12,12,12); policy.setBackground(outline(Color.WHITE,Color.rgb(230,230,230),16)); f.addView(policy); new AlertDialog.Builder(this).setTitle("Marketplace Checkout").setView(f).setNegativeButton("CANCEL",null).setPositiveButton("PLACE ORDER",(di,w)->{if(n.getText().toString().trim().isEmpty()||m.getText().toString().trim().length()<10||a.getText().toString().trim().isEmpty()){toast("Enter valid delivery details");return;}String method=s.isChecked()?"SAMEER delivery":d.isChecked()?"Delivery partner/app":"Self pickup"; String payment=cod.isChecked()?"COD":paytm.isChecked()?"Paytm Business / UPI":"UPI / Online"; int total=0;for(Product q:cart)total+=q.price;sp.edit().putString("last_order","SN"+(System.currentTimeMillis()%100000)+" • ₹"+total+" • "+method+" • "+payment).putString("last_address",a.getText().toString()).apply();cart.clear();new AlertDialog.Builder(this).setTitle("Order confirmed ✓").setMessage("Order placed successfully.\nDelivery: "+method+"\nPayment: "+payment+"\nCustomer care: 6303836274\n\nAll sales are final subject to the stated policy and applicable law.").setPositiveButton("OK",(x,y)->showHome()).show();}).show();}
    void orders(){base();top("My Orders",true);String o=sp.getString("last_order","");if(o.isEmpty())add(content,tv("No orders yet. Your placed orders will appear here.",16,Color.GRAY,false),-1,180,20,50,20,20);else{add(content,tv("Latest order",18,dark,true),-1,35,20,28,20,5);add(content,tv(o+"\n\nAddress: "+sp.getString("last_address",""),15,Color.DKGRAY,false),-1,150,20,0,20,20);}bottom();}
    void account(){base();top("My Account",true);String n=sp.getString("name","Customer");TextView av=tv(n.substring(0,1).toUpperCase(),30,Color.WHITE,true);av.setGravity(17);av.setBackground(bg(purple,60));add(content,av,92,92,0,28,0,10);TextView nm=tv(n,22,dark,true);nm.setGravity(17);add(content,nm,-1,35,0,0,0,4);add(content,tv("Customer care: 6303836274",14,Color.GRAY,false),-1,30,0,0,0,18);Button o=btn("MY ORDERS",dark),w=btn("MY WISHLIST",purple),ad=btn("DELIVERY ADDRESS",green),h=btn("CUSTOMER CARE • 6303836274",orange),r=btn("RETURNS & REFUNDS",blue),lo=btn("LOG OUT",Color.rgb(185,45,45));add(content,o,-1,54,24,4,24,8);add(content,w,-1,54,24,0,24,8);add(content,ad,-1,54,24,0,24,8);add(content,h,-1,54,24,0,24,8);add(content,r,-1,54,24,0,24,8);add(content,lo,-1,54,24,0,24,18);o.setOnClickListener(v->orders());w.setOnClickListener(v->wishlist());ad.setOnClickListener(v->setLocation());h.setOnClickListener(v->help());r.setOnClickListener(v->new AlertDialog.Builder(this).setTitle("No Return / No Refund Policy").setMessage("Supplement orders are final. No returns or refunds for change of mind, taste, opened/used packs, or incorrect selection. If an item arrives wrong, damaged, defective, or a remedy is required by applicable law, contact customer care with your order details.\n\nCustomer care: 6303836274").setPositiveButton("CALL",(d,x)->help()).setNegativeButton("CLOSE",null).show());lo.setOnClickListener(v->{sp.edit().putBoolean("logged",false).apply();showWelcome();});}
    void help(){try{startActivity(new Intent(Intent.ACTION_DIAL, Uri.parse("tel:6303836274")));}catch(Exception e){toast("Customer care: 6303836274");}}
    void toast(String s){Toast.makeText(this,s,Toast.LENGTH_SHORT).show();}
}
