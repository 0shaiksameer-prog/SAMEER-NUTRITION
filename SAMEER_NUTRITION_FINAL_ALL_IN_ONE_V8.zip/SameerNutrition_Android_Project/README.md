# SAMEER NUTRITION — Premium Supplement Store v1.7

Android shopping app prototype for a gym-supplement catalogue.

## Included
- Premium SAMEER NUTRITION colourful branding
- Separate Create Account and Login screens
- Home, search, categories, brands, wishlist, cart, orders and account screens
- Broad catalogue across whey, isolate, vegan protein, casein, gainers, creatine, pre-workout, intra-workout, BCAA/EAA, amino acids, glutamine, citrulline, beta-alanine, L-carnitine, omega-3, multivitamins, vitamin D3, electrolytes, fat burners, snacks and accessories
- Multiple listed brands plus SAMEER NUTRITION products
- Stock quantities shown in catalogue
- Delivery location and delivery-partner choice
- Paytm Business / UPI option label and COD option
- Customer care: 6303836274
- Non-returnable/no-refund policy screen with an exception for remedies required by applicable law

## Important
This is an Android app prototype/storefront. Customer accounts and orders are stored locally on the device. A production store needs a secure backend/database, authenticated account service, server-side order management, and payment verification. Never put payment secrets in the APK or GitHub.
