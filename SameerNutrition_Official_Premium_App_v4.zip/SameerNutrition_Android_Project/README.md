# SAMEER NUTRITION — Official Premium Store v1.3

Premium Android supplement-store catalogue inspired by modern marketplaces. It uses original SAMEER NUTRITION branding and does not copy another company's logo or proprietary UI.

### Included
- Separate Create Account and Login screens
- Colourful SAMEER NUTRITION logo and premium store UI
- Brand-wise catalogue with 60+ stocked catalogue entries
- Pre-workout, creatine, whey, multivitamin, gainer, amino, omega-3, hydration, snacks and accessories
- Stock quantity shown on each product card
- Search by brand/product/category
- Cart and checkout
- SAMEER delivery, delivery-partner/app and self-pickup choices
- My Orders and account page
- Customer care dialer: 6303836274
- GitHub Actions compatible with Gradle 8.7 + Android Gradle Plugin 8.6.1

### Important before public launch
The catalogue contains sample catalogue entries and stock quantities. Replace them with your actual inventory, authorized brands, exact SKUs, prices and legal label information before selling. Do not claim a product is in stock unless you actually have it. For a production store, connect a secure backend for real accounts, inventory, orders, payments and delivery tracking.
